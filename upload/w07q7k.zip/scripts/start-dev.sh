#!/bin/bash
# Persistent dev server startup
cd /home/z/my-project
exec bun run dev
