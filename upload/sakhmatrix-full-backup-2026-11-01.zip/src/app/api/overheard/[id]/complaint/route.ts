/**
 * ШАГ 17 (ТЗ п.22). Жалоба на сообщение «Подслушано Сахалин».
 * Причины: оскорбления; угрозы; травля; мошенничество; спам; реклама;
 * персональные данные; запрещённое содержание; другие нарушения.
 * Жалоба — не голосование: количество жалоб не показывается пользователям
 * и не создаёт никаких оценок; каждая жалоба разбирается ИИ, спорные случаи
 * видит человек-модератор. Массовые жалобы — только сигнал, не доказательство.
 */

import { NextRequest, NextResponse, after } from "next/server";
import { db } from "@/lib/db";
import { handleApiError } from "@/lib/api";
import { moderatePublishedOverheardText, OVERHEARD_COMPLAINT_CATEGORIES, overheardSanctionCategory } from "@/lib/moderation/overheard";
import { handleConfirmedViolation } from "@/lib/moderation/sanctions";
import { checkComplaintAllowed, hasAlreadyComplained, detectRaid } from "@/lib/security";
import { notifyAdmin } from "@/lib/notifications";

import { safeAnonReporterName } from "@/lib/security/complaint-guard";
export const runtime = "nodejs";
export const maxDuration = 120;

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const body = await req.json();
    const category = String(body.category ?? "");
    const comment = String(body.comment ?? "").trim().slice(0, 1000);
    const reporterName = String(body.reporterName ?? "").trim().slice(0, 40);
    const token = String(body.token ?? "");

    if (!OVERHEARD_COMPLAINT_CATEGORIES.includes(category as (typeof OVERHEARD_COMPLAINT_CATEGORIES)[number])) {
      return NextResponse.json({ error: "Выберите причину жалобы" }, { status: 400 });
    }
    const post = await db.overheardPost.findUnique({ where: { id } });
    if (!post || post.isDeleted) {
      return NextResponse.json({ error: "Сообщение не найдено" }, { status: 404 });
    }

    // ПРОМТ №1: rate-limit + уникальность + рейд-детектор.
    const guard = await checkComplaintAllowed(req, token || null, false);
    if (!guard.allowed || guard.response) return guard.response!;
    if (guard.reporterId && (await hasAlreadyComplained("overheardComplaint", { postId: id, reporterId: guard.reporterId }))) {
      return NextResponse.json({ error: "Вы уже жаловались на это сообщение" }, { status: 409 });
    }

    // Жалоба создаётся всегда. Количество жалоб само по себе НЕ является
    // нарушением, не показывается пользователям и не создаёт рейтинг.
    const complaint = await db.overheardComplaint.create({
      data: {
        postId: id,
        category,
        comment,
        reporterName: guard.reporterName ?? safeAnonReporterName(reporterName),
        reporterId: guard.reporterId ?? null,
        aiVerdict: "",
        aiNote: "",
      },
    });

    // ПРОМТ №1: рейд-детектор + ИИ-проверка выполняются в фоне.
    after(async () => {
      try {
        const raid = await detectRaid("overheardComplaint", "postId", id);
        if (raid.isRaid) {
          await db.overheardComplaint.updateMany({
            where: { postId: id },
            data: { aiNote: "Внимание: возможно скоординированная травля (рейд)." },
          }).catch(() => {});
        }
        const outcome = await moderatePublishedOverheardText(post.title, post.text, post.place);
        const verdict =
          outcome.action === "hide" ? "violation" : outcome.action === "human" ? "ambiguous" : "ok";
        await db.overheardComplaint.update({
          where: { id: complaint.id },
          data: { aiVerdict: verdict, aiNote: outcome.aiNote ?? outcome.hiddenReason ?? "" },
        });
        if (outcome.action === "hide") {
          await db.overheardPost.update({
            where: { id },
            data: {
              isHiddenByAi: true,
              hiddenReason: outcome.hiddenReason ?? "нарушение правил раздела",
              aiNote: outcome.aiNote ?? "",
              aiStatus: "hidden",
            },
          });
          if (outcome.source === "ai") {
            await handleConfirmedViolation({
              userId: post.authorId,
              category: overheardSanctionCategory(outcome.overheardCategory ?? category),
              reason: outcome.hiddenReason ?? "нарушение правил раздела «Подслушано Сахалин»",
            });
          }
        }
      } catch {
        // Фоновая проверка не должна ломать ответ пользователю.
      }
    });

    // Уведомление администратора о новой жалобе.


    notifyAdmin({


      type: "complaint",


      section: "Подслушано",


      title: "Новая жалоба в разделе «Подслушано»",


      details: "Категория: " + category + ".",


    }).catch(() => {});


    return NextResponse.json({
      ok: true,
      note: "Жалоба отправлена. Спасибо. Модерация рассмотрит сообщение.",
    });
  } catch (e) {
    return handleApiError(e);
  }
}
