"use client";

/**
 * ТЗ 2026-09-23 «О работодателях» — Flat 2.0 (Пункты 5/6/8/20 ТЗ №2).
 * Самостоятельная страница /o-rabotodatelyah: фиксация СУХОГО, изолированного
 * трудового опыта конкретного человека на острове. Этот раздел имеет самый
 * высокий юридический риск: мы НЕ собираем «чёрные списки» директоров и не
 * выносим публичных приговоров организациям.
 *
 * Трёхколоночная схема Flat 2.0:
 *  ◀️ ЛЕВАЯ КОЛОНКА (Доступ и Поиск компании):
 *     Блок 1 — кнопка «Описать трудовой опыт» + текст снизу (дословно ТЗ);
 *     Блок 2 — «Поиск по организации»: поле «Название компании или ИП» →
 *              «Найти» + фильтр по городам (Южно-Сахалинск, Холмск, Корсаков…).
 *  ⏺️ ЦЕНТРАЛЬНАЯ КОЛОНКА (Лента трудовых фактов): каждая карточка —
 *     изолированная белая карточка в тонкой светло-серой рамке:
 *     📍 Компания (Город) · 📅 Период работы · Личный опыт ·
 *     Особое упоминание человека (принцип «Человек ≠ Организация») ·
 *     дисклеймер · кнопка «💬 Обсудить на форуме» (справа).
 *     Вся живая жизнь, споры и разбор нюансов — в привязанной рубрике форума
 *     «Карьера, бизнес ▸ Работодатели»; на странице только сухой факт.
 *  ▶️ ПРАВАЯ КОЛОНКА (Описание раздела и Защита Персональных Данных):
 *     «О разделе» + «Правила публикации» в рамке (4 пункта дословно).
 *
 * Публикуют только зарегистрированные пользователи; гости только читают
 * ленту. Бездоказательные лозунги («там одни мошенники», «всегда всех
 * обманывают») отклоняются ИИ-фильтром без стирания текста формы.
 *
 * Комментариев, лайков, реакций, рейтингов, кармы, подписок, аватаров НЕТ.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import SakhDatetimeBlock from "@/components/site/sakh-datetime-block";
import type { ForumUser } from "@/lib/ui";
import { discussOnForum } from "@/lib/discuss";
import { SAKHALIN_CITIES } from "@/components/site/flat-board";
import { nickGenderClass } from "@/lib/nick-gender";

interface EmpItem {
  id: string;
  employer: string;
  city: string;
  workPeriod: string;
  experience: string;
  personMention: string;
  authorId: string;
  originalAuthorId?: string | null;
  authorName: string;
  /** 29.09.2026: stance — recommend (зелёная карточка) | notrecommend (красная). */
  stance?: string;
  orgResponseText?: string;
  orgResponseAt?: string | null;
  orgResponseByName?: string;
  editedAt: string | null;
  createdAt: string;
  topicId: number | null;
  topicState?: string; // none | open | closed | archived
  topicAnswers?: number; // 2026-10-17: число ответов в теме (num > 1)
  // 2026-10-17: голоса читателей «Рекомендую» / «Не рекомендую».
  recommendCount?: number;
  notrecommendCount?: number;
  myVote?: string | null; // "recommend" | "notrecommend" | null
  isHiddenByAi?: boolean;
  hiddenReason?: string;
  needHuman?: boolean;
}

interface FeedResponse {
  posts: EmpItem[];
  total: number;
  page: number;
  pages: number;
}

const PAGE_SIZE = 15;

/** ДОСЛОВНЫЕ тексты ТЗ (левая колонка, гость, дисклеймер, правила). */
const EP_ACCESS_NOTE =
  "Чтобы оставить отзыв — войдите в аккаунт.";
const EP_GUEST_HINT =
  "Чтобы оставить отзыв — войдите в свой аккаунт";
const EP_DISCLAIMER =
  "* Публикация отражает личный опыт автора. SakhMatrix предоставляет площадку и скрывает личные контакты физлиц.";
import { EP_RULES_INTRO, EP_RULES } from "@/lib/employers-rules";

/** Дата «23.09.2026» — компактная строка автора карточки. */
function fmtDay(v: string): string {
  const d = new Date(v);
  if (isNaN(d.getTime())) return "";
  return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" });
}

/** Состояния кнопки форума: одинаковый размер и форма для всех (единая
 *  логика ТЗ 2026-09-23 «Кнопки „Обсудить на форуме"»). */
function forumButtonLabel(state: string | undefined, hasAnswers: boolean): string {
  switch (state) {
    case "open":
      // 2026-10-17: «Обсуждается» = есть хотя бы один ответ в теме.
      return hasAnswers ? "💬 Обсуждается на форуме" : "💬 Обсудить на форуме";
    case "closed":
      return "💬 Тема закрыта";
    case "archived":
      return "💬 Тема в архиве";
    default:
      return "💬 Обсудить на форуме";
  }
}

export function EmployersPage(props: {
  user: ForumUser | null;
  token: string | null;
  notify: (m: string) => void;
  onNeedAuth: () => void;
}) {
  const [botNick, setBotNick] = useState<string | null>(null);
  const [items, setItems] = useState<EmpItem[] | null>(null);
  const [stanceFilter, setStanceFilter] = useState<"all" | "recommend" | "notrecommend">("all");
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);

  // Поиск по организации (левая колонка) + фильтр по городам.
  const [q, setQ] = useState("");
  const [appliedQ, setAppliedQ] = useState("");
  const [city, setCity] = useState("");
  const [appliedCity, setAppliedCity] = useState("");

  // Форма: гость → ДОСЛОВНАЯ строка ТЗ (форма НЕ открывается);
  // авторизованный → форма карточки трудового опыта.
  const [formOpen, setFormOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [guestHint, setGuestHint] = useState(false);
  const [rewrite, setRewrite] = useState(false); // ИИ-фильтр лозунгов сработал (Пункт 8 ТЗ №2)
  const [formEmployer, setFormEmployer] = useState("");
  const [formStance, setFormStance] = useState<"recommend" | "notrecommend">("recommend");
  const [formCity, setFormCity] = useState("");
  const [formPeriod, setFormPeriod] = useState("");
  const [formExperience, setFormExperience] = useState("");
  const [formMention, setFormMention] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [note, setNote] = useState("");

  const [highlightId, setHighlightId] = useState<string | null>(null);
  const listTopRef = useRef<HTMLDivElement | null>(null);

  // 2026-10-16: fetch random bot for preview


  useEffect(() => {


    fetch("/api/auto-bots/random").then(r => r.json()).then(d => {


      if (d.nickname) setBotNick(d.nickname);


    }).catch(() => {});


  }, []);



  const load = useCallback(
    async (opts: { page?: number; q?: string; city?: string } = {}) => {
      const p = opts.page ?? 1;
      const qq = opts.q ?? appliedQ;
      const cc = opts.city ?? appliedCity;
      const sp = new URLSearchParams({ page: String(p), pageSize: String(PAGE_SIZE) });
      if (qq) sp.set("q", qq);
      if (cc) sp.set("city", cc);
      if (props.token) sp.set("token", props.token);  // 2026-10-17: для myVote
      try {
        const r = await fetch(`/api/employers?${sp.toString()}`);
        const d: FeedResponse = await r.json();
        setItems(d.posts ?? []);
        setTotal(Number(d.total ?? d.posts?.length ?? 0));
        setPage(Number(d.page ?? p));
        setPages(Math.max(1, Number(d.pages ?? 1)));
      } catch {
        setItems([]);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [appliedQ, appliedCity, props.token]
  );

  // Применение поиска/города — без перезагрузки страницы.
  // 2026-10-17: зависимость от props.token — перезагружаем ленту после того,
  // как useAuth достанет токен из localStorage (изначально он null при SSR).
  useEffect(() => {
    setItems(null);
    load({ page: 1 });
  }, [load]);

  // Глубокая ссылка из темы форума: /o-rabotodatelyah?post=ID — подсветить карточку.
  useEffect(() => {
    const postId = new URLSearchParams(window.location.search).get("post");
    if (!postId) return;
    setHighlightId(postId);
    const t = window.setInterval(() => {
      const el = document.querySelector(`[data-ep-card="${postId}"]`);
      if (el) {
        el.scrollIntoView({ block: "center" });
        window.clearInterval(t);
        window.setTimeout(() => setHighlightId(null), 4000);
      }
    }, 300);
    window.setTimeout(() => window.clearInterval(t), 12000);
    return () => window.clearInterval(t);
  }, [items]);

  const applySearch = () => {
    setAppliedQ(q.trim());
    setAppliedCity(city.trim());
  };

  const resetSearch = () => {
    setQ("");
    setCity("");
    setAppliedQ("");
    setAppliedCity("");
  };

  const searching = !!(appliedQ || appliedCity);

  /** «Описать трудовой опыт»: гостю — ДОСЛОВНАЯ строка ТЗ (форма НЕ
   *  открывается), авторизованному — форма карточки опыта. */
  const openForm = () => {
    setNote("");
    if (!(props.user && props.token)) {
      setGuestHint(true);
      setFormOpen(false);
      return;
    }
    setGuestHint(false);
    setRewrite(false);
    setErr("");
    setEditId(null);  // 2026-10-17: ensure form is in "create" mode
    setFormStance("recommend");  // 2026-10-17: default position for new review
    setFormOpen(true);
  };

  // 2026-10-17: голос читателя «Рекомендую» / «Не рекомендую».
  const vote = async (item: EmpItem, kind: "recommend" | "notrecommend") => {
    if (!props.user) {
      props.onNeedAuth();
      return;
    }
    try {
      const r = await fetch(`/api/employers/${item.id}/support`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: props.token, kind }),
      });
      const d = await r.json();
      if (!r.ok) throw Error(d.error || "Не удалось учесть голос");
      setItems((prev) =>
        (prev ?? []).map((p) =>
          p.id === item.id
            ? {
                ...p,
                recommendCount: d.recommendCount ?? p.recommendCount,
                notrecommendCount: d.notrecommendCount ?? p.notrecommendCount,
                myVote: d.myVote ?? null,
              }
            : p
        )
      );
      if (d.note) props.notify(d.note);
    } catch (e) {
      props.notify(e instanceof Error ? e.message : "Ошибка");
    }
  };

  // 2026-10-17: открыть форму в режиме редактирования (заполнить поля).
  const openEdit = (item: EmpItem) => {
    setEditId(item.id);
    setFormEmployer(item.employer);
    setFormCity(item.city);
    setFormPeriod(item.workPeriod);
    setFormExperience(item.experience);
    setFormMention(item.personMention);
    // 2026-10-17: при редактировании можно сменить позицию автора.
    setFormStance(item.stance === "notrecommend" ? "notrecommend" : "recommend");
    setFormOpen(true);
  };

  const publish = async () => {
    setErr("");
    setRewrite(false);
    // Проверки дублируют API (одинаковые сообщения).
    if (formEmployer.trim().length < 2) {
      return setErr("Укажите официальное название компании или ИП");
    }
    if (!formCity.trim()) {
      return setErr("Выберите город, где находится организация");
    }
    if (formPeriod.trim().length < 2) {
      return setErr("Укажите период работы (например: май – август 2026 г.)");
    }
    if (formExperience.trim().length < 10) {
      return setErr("Опишите личный опыт: конкретно, с чем столкнулись лично (от 10 до 8000 символов)");
    }
    setBusy(true);
    try {
      // 2026-10-17: если editId задан — PATCH (редактирование), иначе POST (создание).
      const isEdit = !!editId;
      const url = isEdit ? `/api/employers/${editId}` : "/api/employers";
      const method = isEdit ? "PATCH" : "POST";
      const payload: Record<string, unknown> = {
        token: props.token,
        employer: formEmployer.trim(),
        city: formCity.trim(),
        workPeriod: formPeriod.trim(),
        experience: formExperience.trim(),
        personMention: formMention.trim(),
        stance: formStance,  // 2026-10-17: позиция автора — recommend | notrecommend
      };
      if (!isEdit) payload.confirmSimilar = true;
      if (isEdit) payload.action = "edit";
      const r = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const d = await r.json();
      if (!r.ok) {
        // ИИ-фильтр лозунгов (Пункт 8 ТЗ №2): публикация отклонена, но текст
        // НЕ стирается — форма остаётся с текстом автора, показывается
        // ДОСЛОВНОЕ сообщение с предложением переписать фактами.
        if (d.rewrite) {
          setRewrite(true);
          return;
        }
        throw Error(d.error || "Не удалось опубликовать карточку опыта.");
      }
      // Успех: форма закрывается, поля чистятся, карточка падает наверх ленты.
      setFormOpen(false);
      setEditId(null);
      setFormEmployer("");
      setFormStance("recommend");
      setFormCity("");
      setFormPeriod("");
      setFormExperience("");
      setFormMention("");
      setNote(d.note || "Опыт опубликован. Спасибо!");
      props.notify(d.note || "Опыт опубликован. Спасибо!");
      window.setTimeout(() => setNote(""), 5000);
      await load({ page: 1 });
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Ошибка публикации");
    } finally {
      setBusy(false);
    }
  };

  const goToPage = async (p: number) => {
    await load({ page: p });
    listTopRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const list = items ?? [];

  return (
    <div className="ep-layout main-grid-container" data-ep-layout="1">
      {/* ============ ЛЕВАЯ КОЛОНКА — «О разделе» (правка 1+2+3, 28.09.2026) ============
          Прежние блоки (Доступ + Поиск по организации) УБРАНЫ.
          «О разделе» перемещён сюда из правой колонки и оформлен в дизайне
          блока «Время» (.sakh-clock: тёмно-синяя шапка #1E3A5F, белое тело). */}
      <aside className="left-column">
        <div className="sakh-clock ep-clock-block ep-clock-about" data-ep-about="1">
          <div className="sakh-clock-head">ℹ️ О разделе</div>
          <div className="sakh-clock-body sakh-clock-body-content">
            {/* 04.10.2026: мобильная версия «О разделе» сокращена до
                главной сути; полный текст виден только на десктопе. */}
            <div className="ep-info about-full" data-ep-about-text="1">
              <p>
                «О работодателях» — это инструмент фиксации реального трудового опыта жителей Сахалина и Курил.
              </p>
              <p>
                Раздел создан не для травли или вынесения публичных приговоров организациям, а для обмена честными фактами. Мы
                не ведем «черных списков» компаний и не выносим коллективный вердикт. SakhMatrix предоставляет площадку для
                высказывания, но не является автором пользовательских утверждений.
              </p>
            </div>
            <div className="ep-info about-short">
              <p>
                Честный обмен фактами о трудовом опыте на Сахалине и Курилах. Не «чёрные списки» и не травля, а
                фиксация реального опыта. Представитель организации может дать один официальный ответ.
              </p>
            </div>
          </div>
        </div>

        {/* 29.09.2026: блок «🎨 Цвета карточек» — как на /rekomenduyu. */}
        <div className="sakh-clock ep-clock-block ep-clock-legend">
          <div className="sakh-clock-head">🎨 Цвета карточек</div>
          <div className="sakh-clock-body sakh-clock-body-content">
            <div className="ep-legend">
              <div className="ep-legend-row">
                <span className="ep-legend-swatch swatch-positive" />
                <div>
                  <b>Зелёная рамка</b> — автор рекомендует работодателя (положительный опыт работы).
                </div>
              </div>
              <div className="ep-legend-row">
                <span className="ep-legend-swatch swatch-negative" />
                <div>
                  <b>Красная рамка</b> — автор не рекомендует (отрицательный опыт). Критика разрешена — это суть раздела.
                </div>
              </div>
              <p className="ep-legend-note">
                Раздел фиксирует сухой личный трудовой опыт. Цвет рамки — это позиция автора на момент публикации, основанная на личном опыте.
              </p>
            </div>
          </div>
        </div>
      </aside>

      {/* ============ ЦЕНТРАЛЬНАЯ КОЛОНКА (Лента трудовых фактов) ============ */}
      <div className="center-column">
        <div className="ep-head" data-ep-head="1">
          <h1 className="ep-title" data-ep-title="1">
            О работодателях
          </h1>
          <div className="ep-desc" data-ep-desc="1">
            Сухая фиксация личного трудового опыта: компания, период работы, факты — без лозунгов и «чёрных списков».
          </div>
          <button className="ep-newbtn" data-ep-add-center="1" onClick={openForm}>
            Описать трудовой опыт
          </button>
          {/* Логика доступа: гость кликнул → ДОСЛОВНАЯ строка ТЗ, форма НЕ открыта. */}
          {guestHint && (
            <div className="ep-guesthint" data-ep-guesthint="1" role="alert">
              {EP_GUEST_HINT}
            </div>
          )}
        </div>

        {/* Форма карточки трудового опыта (только для вошедших). */}
        {formOpen && props.token && (
          <div className="ep-form" data-ep-form="1">
            {/* 2026-10-17: позиция автора — рекомендует или не рекомендует.
                Видна и при создании, и при редактировании. */}
            <div className="ep-step" data-ep-field-stance="1">
              <label className="ep-steplabel">
                Ваша позиция <span className="ep-step-hint">Определяет цвет карточки: зелёная — рекомендую, красная — не рекомендую</span>
              </label>
              <div className="ep-stances">
                <label className="complaint-option">
                  <input
                    type="radio"
                    name="ep-stance"
                    value="recommend"
                    checked={formStance === "recommend"}
                    onChange={() => setFormStance("recommend")}
                  />
                  Рекомендую — опыт положительный
                </label>
                <label className="complaint-option">
                  <input
                    type="radio"
                    name="ep-stance"
                    value="notrecommend"
                    checked={formStance === "notrecommend"}
                    onChange={() => setFormStance("notrecommend")}
                  />
                  Не рекомендую — опыт отрицательный
                </label>
              </div>
            </div>
            <div className="ep-step" data-ep-field-employer="1">
              <label className="ep-steplabel" htmlFor="ep-f-employer">
                Компания / ИП <span className="ep-step-hint">Только официальное название организации</span>
              </label>
              <input
                id="ep-f-employer"
                data-ep-employer="1"
                value={formEmployer}
                maxLength={120}
                onChange={(e) => {
                  setFormEmployer(e.target.value);
                  setErr("");
                }}
                placeholder="Например: ООО «Сахалин-Строй-Ресурс»"
              />
            </div>
            <div className="ep-step2-grid" data-ep-field-city="1">
              <div>
                <label className="ep-steplabel" htmlFor="ep-f-city">
                  Город
                </label>
                <select
                  id="ep-f-city"
                  className="ep-cityfilter"
                  data-ep-city="1"
                  value={formCity}
                  onChange={(e) => setFormCity(e.target.value)}
                >
                  <option value="">Выберите город…</option>
                  {SAKHALIN_CITIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="ep-steplabel" htmlFor="ep-f-period">
                  Период работы <span className="ep-step-hint">когда вы работали</span>
                </label>
                <input
                  id="ep-f-period"
                  data-ep-period="1"
                  value={formPeriod}
                  maxLength={120}
                  onChange={(e) => {
                    setFormPeriod(e.target.value);
                    setErr("");
                  }}
                  placeholder="Например: май – август 2026 г."
                />
              </div>
            </div>
            <div className="ep-step" data-ep-field-experience="1">
              <label className="ep-steplabel" htmlFor="ep-f-experience">
                Личный опыт <span className="ep-step-hint">конкретно: даты, условия, факты выплат или задержек — без лозунгов</span>
              </label>
              <textarea
                id="ep-f-experience"
                data-ep-experience="1"
                value={formExperience}
                maxLength={8000}
                onChange={(e) => {
                  setFormExperience(e.target.value);
                  setErr("");
                }}
                placeholder="Например: работал на строительном объекте в Дальнем. Возникла проблема с задержкой окончательного расчёта при увольнении на две недели."
              />
            </div>
            <div className="ep-step" data-ep-field-mention="1">
              <label className="ep-steplabel" htmlFor="ep-f-mention">
                Особое упоминание человека <span className="ep-step-hint">необязательно — «Человек ≠ Организация»: можно отдельно поблагодарить сотрудника (только рабочее имя, без телефонов и адресов)</span>
              </label>
              <textarea
                id="ep-f-mention"
                data-ep-mention="1"
                value={formMention}
                maxLength={2000}
                onChange={(e) => {
                  setFormMention(e.target.value);
                  setErr("");
                }}
                placeholder="Например: отдельно хочу отметить начальника участка Дмитрия Николаевича — он лично контролировал ведомости и помог мне закрыть смены. К его работе претензий нет."
                style={{ minHeight: 66 }}
              />
            </div>
            <div className="ep-formfoot">
              <button className="sk-btn-classic" data-ep-publish="1" disabled={busy} onClick={publish} style={{ borderRadius: 0 }}>
                {busy ? "Проверка…" : editId ? "Сохранить" : "Опубликовать"}
              </button>
            </div>
            {/* ИИ-фильтр лозунгов (Пункт 8 ТЗ №2): дословное сообщение,
                текст в форме СОХРАНЁН для переписывания. */}
            {rewrite && (
              <div className="ep-rewrite" data-ep-rewrite="1" role="alert">
                Публикация отклонена фильтром. {err || "Пожалуйста, переформулируйте: укажите конкретный факт (с чем вы столкнулись лично: даты, условия работы, факты выплат или задержек). Бездоказательные лозунги («там одни мошенники», «всегда всех обманывают») отклоняются фильтром"}
              </div>
            )}
            {err && !rewrite && (
              <div className="ep-err" data-ep-err="1" role="alert">
                {err}
              </div>
            )}
          </div>
        )}

        <div ref={listTopRef} />

        {items === null && <div className="ep-empty">Загрузка…</div>}

        {items !== null && list.length === 0 && (
          <div className="ep-empty" data-ep-empty="1">
            {searching
              ? "По запросу ничего не найдено. Попробуйте изменить название компании или город."
              : "Пока нет карточек опыта — ваша может стать первой."}
          </div>
        )}

        {/* Лента карточек: изолированные белые карточки в тонкой светло-серой
            рамке, новые сверху (ТЗ Flat 2.0). */}
        {/* 2026-10-18: вкладки-маркеры в стиле картотеки */}
        {items !== null && (
          <div className="status-tabs">
            <button className={"status-tab tab-all" + (stanceFilter === "all" ? " is-active" : "")}
              onClick={() => setStanceFilter("all")}>
              <span className="status-tab-label">Все</span>
            </button>
            <button className={"status-tab tab-recommend" + (stanceFilter === "recommend" ? " is-active" : "")}
              onClick={() => setStanceFilter("recommend")}>
              <span className="status-tab-label">👍 Рекомендую</span>
            </button>
            <button className={"status-tab tab-notrecommend" + (stanceFilter === "notrecommend" ? " is-active" : "")}
              onClick={() => setStanceFilter("notrecommend")}>
              <span className="status-tab-label">👎 Не рекомендую</span>
            </button>
          </div>
        )}

        {items !== null && list.length > 0 && (
          <div data-ep-cards="1">
            {list.filter(it => stanceFilter === "all" || (it.stance ?? "recommend") === stanceFilter).map((it) => {
              const state = it.topicId ? it.topicState ?? "open" : "none";
              return (
                <article key={it.id} className={`ep-card${it.stance === "recommend" ? " ep-positive" : it.stance === "notrecommend" ? " ep-negative" : ""}${highlightId === it.id ? " ep-highlight" : ""}`} data-ep-card={it.id}>
                  <div className="ep-card-top">
                    <span className="ep-card-place" data-ep-card-place={it.id}>
                      📍 {it.employer} ({it.city})
                    </span>
                    <span className="ep-card-meta" data-ep-card-meta={it.id}>
                      <b className={nickGenderClass(it.authorName, it.authorGender)}>{it.authorName || "Аноним"}</b> · {fmtDay(it.createdAt)}
                      {it.editedAt ? " · изменено автором" : ""}
                    </span>
                  </div>
                  {/* 📅 Период работы — строка ТЗ. */}
                  {it.workPeriod && (
                    <div className="ep-card-period" data-ep-card-period={it.id}>
                      📅 Период работы: {it.workPeriod}
                    </div>
                  )}
                  <div className="ep-sep" />
                  {/* Личный опыт — сухой факт без лозунгов (Пункт 8 ТЗ №2). */}
                  <div className="ep-card-row">
                    <span className="ep-rowlabel">Личный опыт:</span>
                    <div className="ep-card-text" data-ep-card-text={it.id}>
                      {it.experience}
                    </div>
                  </div>
                  {/* «Человек ≠ Организация» (Пункты 5/6 ТЗ №2): отдельно
                      выделяем хорошего сотрудника, даже если компания подвела. */}
                  {it.personMention && (
                    <div className="ep-card-row" data-ep-card-mention-row={it.id}>
                      <span className="ep-rowlabel">Особое упоминание человека:</span>
                      <div className="ep-card-text ep-card-mention" data-ep-card-mention={it.id}>
                        {it.personMention}
                      </div>
                    </div>
                  )}
                  <div className="ep-sep" />
                  {/* Дисклеймер (ТЗ, юридическая защита площадки). */}
                  <div className="ep-card-disclaimer" data-ep-card-disclaimer={it.id}>
                    {EP_DISCLAIMER}
                  </div>
                  {/*
                    ТЗ 2026-09-24 «Обсудить на форуме — авто-создание темы»:
                    button вместо <a> — действие создаёт тему, а не навигация.
                    POST /api/discuss/employers/<postId>:
                      • если есть topicId — редирект в существующую тему;
                      • если нет — создаёт тему в рубрике «Работодатели» от
                        имени текущего пользователя, привязывает к карточке,
                        редиректит в новую тему.
                    Тема формируется из employer + city + workPeriod + experience
                    + personMention (новые поля Flat 2.0, не legacy title/text).
                  */}
                  <div className="ep-card-foot">
                    {/* 29.09.2026: орг. ответ — ВО ВСЮ ШИРИНУ карточки. */}
                    {it.orgResponseText ? (
                      <div style={{ width: "100%", padding: "6px 8px", background: "#e0f2fe", border: "1px solid #0284c7", borderRadius: "2px", marginBottom: "6px", fontSize: "13px", boxSizing: "border-box" }}>
                        <b style={{ color: "#075985" }}>🏢 Ответ организации</b>
                        {it.orgResponseByName ? <span style={{ color: "#56657a" }}> · {it.orgResponseByName}</span> : null}
                        <p style={{ margin: "4px 0 0", color: "#1a2433" }}>{it.orgResponseText}</p>
                      </div>
                    ) : null}
                    {/* 29.09.2026: «🏢 Ответ организации» — В ОДНОЙ строке с «💬 Обсудить на форуме» (оба справа). */}
                    {props.user?.orgRep && props.user.id !== it.authorId && !it.orgResponseText && props.token ? (
                        <button
                          type="button"
                          onClick={async () => {
                            const text = window.prompt("Введите официальный ответ организации:");
                            if (!text || text.trim().length < 10) { props.notify("Текст ответа: от 10 символов"); return; }
                            try {
                              const r = await fetch(`/api/employers/${it.id}`, {
                                method: "PATCH",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ token: props.token, action: "orgResponse", text: text.trim() }),
                              });
                              const d = await r.json();
                              if (!r.ok) { props.notify(d.error || "Ошибка"); return; }
                              props.notify(d.note || "Ответ опубликован");
                              load();
                            } catch { props.notify("Сеть недоступна"); }
                          }}
                          title="Официальный ответ организации — виден только представителю, ровно один ответ"
                          style={{ cursor: "pointer", background: "#e0f2fe", border: "1px solid #0284c7", color: "#075985", padding: "6px 14px", fontFamily: "inherit", fontSize: "13px", fontWeight: 700, whiteSpace: "nowrap", borderRadius: "2px" }}
                        >
                          🏢 Ответ организации
                        </button>
                    ) : null}
                    {/* 29.09.2026: «💬 Обсудить на форуме» — ПОД ответом организации,
                        на отдельной строке. */}
                    <button
                      type="button"
                      className={`ep-btn-forum is-${state}`}
                      data-ep-card-forum={it.id}
                      onClick={() => discussOnForum("employers", it.id, props.token, props.onNeedAuth)}
                      title="Создать тему обсуждения в рубрике «Карьера, бизнес ▸ Работодатели»"
                    >
                      {forumButtonLabel(it.topicId ? it.topicState : "none", (it.topicAnswers ?? 0) >= 1)}
                    </button>
                    {/* 2026-10-17: Admin/author edit + delete buttons */}
                    {props.user && props.user.id && (props.user.role === "owner" || props.user.role === "admin" || props.user.role === "moderator" || (it.authorId != null && props.user.id === it.authorId) || (it.originalAuthorId != null && props.user.id === it.originalAuthorId)) && (
                      <>
                        <button
                          type="button"
                          onClick={() => openEdit(it)}
                          className="ep-btn-edit"
                          title="Редактировать отзыв"
                        >
                          Редактировать
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            if (!window.confirm("Удалить отзыв?")) return;
                            try {
                              const r = await fetch(`/api/employers/${it.id}`, {
                                method: "PATCH",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ token: props.token, action: "delete" }),
                              });
                              const d = await r.json();
                              if (!r.ok) { props.notify(d.error || "Ошибка"); return; }
                              props.notify("Отзыв удалён");
                              load();
                            } catch { props.notify("Сеть недоступна"); }
                          }}
                          className="ep-btn-delete"
                        >
                          Удалить
                        </button>
                      </>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}

        {/* Пагинация под лентой — как в других разделах. */}
        {items !== null && pages > 1 && (
          <div className="ep-pager" data-ep-pager="1">
            <button data-ep-pager-prev="1" disabled={page <= 1} onClick={() => goToPage(page - 1)}>
              ← Новее
            </button>
            <span data-ep-pager-info="1">
              Страница {page} из {pages} · всего {total}
            </span>
            <button data-ep-pager-next="1" disabled={page >= pages} onClick={() => goToPage(page + 1)}>
              Старее →
            </button>
          </div>
        )}
        {items !== null && pages === 1 && total > 0 && (
          <div className="ep-pager" data-ep-pager="1">
            <span data-ep-pager-info="1">Всего {total} · новые сверху</span>
          </div>
        )}

        {note && (
          <div className="ep-noteok" data-ep-note="1" role="status">
            {note}
          </div>
        )}
      </div>

      {/* ==== ПРАВАЯ КОЛОНКА — Время + Правила (правки 28.09.2026) ====
          «О разделе» убран (теперь он в левой колонке).
          «Правила публикации» оформлены в дизайне блока «Время» (.sakh-clock). */}
      <aside className="right-column">
        <SakhDatetimeBlock />
        {/* 2026-10-16: Recommendation for employers */}
        <div className="ep-emp-recblock">
          <div className="ep-emp-recblock-head">📋 Рекомендация для работодателей</div>
          <div className="ep-emp-recblock-body">
            Если в отзыве есть претензии к вашей компании — свяжитесь с автором напрямую, чтобы урегулировать разногласия. Зарегистрируйтесь как представитель организации и оставьте официальный ответ под отзывом.
          </div>
        </div>
        <div className="sakh-clock ep-clock-block ep-clock-orgrep">
          <div className="sakh-clock-head">🏢 Ответ представителя</div>
          <div className="sakh-clock-body sakh-clock-body-content">
            <div className="ep-info">
              <p style={{ marginBottom: 6 }}>
                <b>Как стать представителем:</b>
              </p>
              <ol style={{ paddingLeft: 20, margin: "4px 0 8px", fontSize: 13, lineHeight: 1.5 }}>
                <li>Зарегистрируйтесь на сайте.</li>
                <li>Обратитесь к администрации для подтверждения статуса.</li>
                <li>После подтверждения — под отзывом появится кнопка «🏢 Ответ организации».</li>
              </ol>
              <a href="/o-rabotodatelyah/org-response" style={{ fontSize: 13, color: "#0a5caa", fontWeight: 600 }}>Подробности →</a>
            </div>
          </div>
        </div>
        <div className="sakh-clock ep-clock-block ep-clock-rules" data-ep-rules="1">
          <div className="sakh-clock-head">⚠️ Правила публикации</div>
          <div className="sakh-clock-body sakh-clock-body-content">
            <div className="ep-rulesframe" data-ep-rules-frame="1">
              <div className="ep-keyrule" style={{ fontSize: 13, lineHeight: 1.5 }}>
                Пишите конкретно о личном опыте. Без лозунгов, личных данных физлиц и рекламы. Обсуждения — на форуме.
              </div>
              <a href="/o-rabotodatelyah/rules" style={{ fontSize: 13, color: "#0a5caa", fontWeight: 600, display: "block", marginTop: 8 }}>Подробности →</a>
            </div>
          </div>
        </div>
      </aside>
    </div>
  );
}
