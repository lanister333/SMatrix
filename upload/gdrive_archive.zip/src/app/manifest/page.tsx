"use client";

/**
 * ТЗ 2026-09-25 «Манифест доверия SakhMatrix» — отдельная страница /manifest.
 *
 * На ней размещён ПОЛНЫЙ текст Манифеста со всеми 5 пунктами:
 *   1. Живой организм Сахалина
 *   2. Главный принцип: Не обвинить — обозначить
 *   3. Мнение автора ≠ Позиция сайта
 *   4. Свобода без базара
 *   5. Человек не равен организации
 *
 * Сюда ведёт ссылка «Читать манифест полностью →» из сокращённого блока
 * Манифеста в правой колонке (src/components/forum/manifest-trust.tsx).
 *
 * Дизайн — в стиле сайта: общий каркас (Masthead, MainNav, SiteFooter),
 * блок с синей шапкой (sk-sidezone + sk-blocktitle с маркером ▼), белое
 * тело, рамка, аккуратные отступы.
 */

import { useEffect, useState } from "react";
import { DEFAULT_SETTINGS, isStaffRole, MainNav, Masthead, SiteFooter, useAuth, type SiteSettings } from "@/components/site/chrome";

export default function ManifestPage() {
  const { user } = useAuth();
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);

  // Общие настройки сайта для шапки и футера (те же, что и на форуме)
  useEffect(() => {
    fetch("/api/bootstrap")
      .then((r) => r.json())
      .then((r) => {
        if (r.settings) setSettings({ ...DEFAULT_SETTINGS, ...r.settings });
      })
      .catch(() => {});
  }, []);

  const goNav = (k: string) => {
    if (k === "home") {
      window.location.href = "/";
      return;
    }
    window.location.href = k === "home" ? "/" : `/?view=${k}`;
  };

  return (
    <div className="sm-page flex min-h-screen flex-col">
      <Masthead settings={settings} />
      <MainNav current="home" isAdmin={isStaffRole(user?.role)} onNavigate={goNav} />
      <div className="sk" style={{ minHeight: 0, flex: "1 0 auto" }}>
        <div className="sk-topbar">
          <span className="tb-title">Манифест доверия SakhMatrix</span>
        </div>
        <div className="sk-shell">
          <div style={{ margin: "0 auto", maxWidth: 820, padding: "20px 14px 26px" }} data-manifest-page="1">

            {/* Блок в стиле сайта — синяя шапка + белое тело с рамкой */}
            <div className="sk-sidezone sk-manifest-full">
              <div className="sk-blocktitle">
                <span className="tri">▼</span>👥 Манифест доверия SakhMatrix
              </div>

              <div className="sk-manifest-full-content">
                {/* Слоган — курсивом, выделен */}
                <p className="sk-manifest-slogan">«Спроси у города — город ответит.»</p>

                {/* Пункт 1 */}
                <h3 className="sk-manifest-h">• Живой организм Сахалина</h3>
                <p className="sk-manifest-p">
                  SakhMatrix — это пространство бесплатной взаимопомощи жителей острова.
                  Наша сила — в честном личном опыте, знаниях и готовности помогать друг
                  другу. Роли меняются: сегодня ты просишь совета, а завтра сам помогаешь
                  городу.
                </p>

                {/* Пункт 2 */}
                <h3 className="sk-manifest-h">• Главный принцип: Не обвинить — обозначить</h3>
                <p className="sk-manifest-p">
                  Мы не площадка для травли, пустых споров или вынесения приговоров. Мы
                  фиксируем сухие факты, даты, обстоятельства и конкретный личный опыт
                  жителей.
                </p>

                {/* Пункт 3 */}
                <h3 className="sk-manifest-h">• Мнение автора ≠ Позиция сайта</h3>
                <p className="sk-manifest-p">
                  Все публикации на форуме и в сервисах отражают исключительно личный
                  опыт и сведения, предоставленные их авторами. Они не являются
                  официальной позицией, оценкой, одобрением или мнением администрации
                  SakhMatrix.
                </p>

                {/* Пункт 4 */}
                <h3 className="sk-manifest-h">• Свобода без базара</h3>
                <p className="sk-manifest-p">
                  Критика, несогласие и негативный опыт на острове разрешены — это часть
                  живой жизни. Но оскорбления, ярлыки, спам и слив чужих личных данных
                  физлиц (мобильные телефоны, адреса) жестко блокируются модерацией.
                </p>

                {/* Пункт 5 */}
                <h3 className="sk-manifest-h">• Человек не равен организации</h3>
                <p className="sk-manifest-p">
                  Плохой опыт с компанией не значит, что все сотрудники плохие. Вы всегда
                  можете отдельно похвалить и поблагодарить конкретного специалиста,
                  мастера или врача за хорошую работу.
                </p>

                {/* Кнопка «Назад к форуму» */}
                <div className="sk-manifest-back">
                  <a href="/" className="sk-manifest-back-link">← Вернуться на главную</a>
                </div>
              </div>
            </div>

          </div>
        </div>
        <SiteFooter settings={settings} />
      </div>
    </div>
  );
}
