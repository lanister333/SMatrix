"use client";

/**
 * ТЗ 2026-09-25 «Единый шаблон шапки темы форума» (src/components/forum/topic-bar.tsx).
 *
 * Это ЕДИНЫЙ React-компонент, который рендерит верхний блок любой темы форума.
 * Подключается в src/components/forum/topic-view.tsx — это единственный
 * компонент, который рендерит страницу темы. Все темы (старые и новые,
 * включая созданные через NewTopicModal или авто-созданные из отзывов через
 * POST /api/discuss/[kind]/[id]) проходят через этот путь — значит, любая
 * правка шапки в TopicBar применяется автоматически ко всем темам без
 * ручной работы.
 *
 * Структура: 4 блока сверху вниз (по скриншоту заказчика):
 *   БЛОК 1 — хлебные крошки (мелкий серый, разделитель →);
 *   БЛОК 2 — заголовок темы в РАМКЕ (крупный жирный СИНИЙ);
 *   БЛОК 3 — метаданные (мелкий серый; ник автора — жирный + цвет по полу);
 *   БЛОК 4 — кнопки: «Ответить» (синяя большая) + «★» (В избранное) +
 *            «Поиск по теме» + «⋮ Действия» (Закрыть/Удалить тему —
 *            выпадающее меню только для админов).
 *
 * CSS — в src/app/globals.css (классы .sk-topic-bar, .sk-topic-bar__*).
 */

import type { ForumUser } from "@/lib/ui";
import { Nick, fmtNum, fmtDateTime, fmtRecent } from "@/lib/ui";

interface FavoritesApi {
  ids: number[];
  toggle: (id: number) => void;
  has: (id: number) => boolean;
}

interface TopicBarProps {
  /** Данные темы. */
  topic: Record<string, unknown>;
  /** ID темы (число). */
  topicId: number;
  /** Число ответов. */
  answers: number;
  /** Число непрочитанных сообщений. */
  newCount: number;
  /** Текущий пользователь. */
  user: ForumUser | null;
  /** true, если пользователь — админ/модератор/владелец. */
  isAdmin: boolean;
  /** true, если пользователь — автор темы. */
  isOwner: boolean;
  /** API избранного: has(id) + toggle(id). */
  favorites: FavoritesApi;
  /** Поиск по теме: открыт ли блок, текущий запрос, setters. */
  inTopicSearch: boolean;
  topicQ: string;
  setInTopicSearch: (v: boolean) => void;
  setTopicQ: (v: string) => void;
  /** Колбэк: действие с темой (close/open/delete) — для админов. */
  topicAction: (action: string, okMsg: string, after?: () => void) => void;
  /** Колбэк: при клике «Ответить». */
  onReply: () => void;
  /** Колбэк: при клике «На главную форума». */
  onGoForumHome: () => void;
  /** Колбэк: при клике на рубрику/подраздел в крошках. */
  onOpenRubric: (r: { slug: string; name: string } | null) => void;
  /** Колбэк: при клике на ник автора. */
  onOpenProfile: (n: string) => void;
  /** Колбэк: при клике «Перейти к новым сообщениям». */
  onJumpToNew: () => void;
  /** Колбэк: показать всплывающее уведомление. */
  notify: (m: string) => void;
}

export function TopicBar(props: TopicBarProps) {
  const { topic, topicId, answers, newCount } = props;
  const isFav = props.favorites.has(topicId);
  const isArchived = !!topic.isArchived;
  const isClosed = !!topic.isClosed;
  const isPinned = !!topic.isPinned;

  return (
    <header className="sk-topic-bar">
      {/* БЛОК 1 — Хлебные крошки (мелкий серый, разделитель →).
          Без названия темы в конце — заголовок в БЛОК 2. */}
      <nav className="sk-topic-bar__crumbs" aria-label="Навигация по форуму">
        <a onClick={props.onGoForumHome} title="На главную страницу форума">Форум</a>
        <span className="sep">→</span>
        {topic.rubricName ? (
          <>
            <a onClick={() => props.onOpenRubric({ slug: (topic.rubricSlug as string) || "", name: topic.rubricName as string })}>
              {topic.rubricName as string}
            </a>
            <span className="sep">→</span>
          </>
        ) : null}
        {topic.subName ? (
          <a onClick={() => props.onOpenRubric({ slug: (topic.subSlug as string) || "", name: `${topic.rubricName} → ${topic.subName}` })}>
            {topic.subName as string}
          </a>
        ) : null}
      </nav>

      {/* БЛОК 2 — Заголовок темы в РАМКЕ (крупный жирный СИНИЙ).
          Бейджи статуса (Закреплена/В архиве/Тема закрыта) — рядом. */}
      <div className="sk-topic-bar__title-wrap">
        <h1 className="sk-topic-bar__title">{topic.title as string}</h1>
        {isPinned && <span className="sk-tstatus pinned">Закреплена</span>}
        {isArchived ? (
          <span className="sk-tstatus archived">В архиве</span>
        ) : (
          isClosed && <span className="sk-tstatus closed">Тема закрыта</span>
        )}
      </div>

      {/* БЛОК 3 — Метаданные (мелкий серый; ник автора — жирный + цвет
          по полу через компонент Nick). Слова вместо иконок (Просмотров:,
          Ответов:) — по ТЗ скриншота. */}
      <div className="sk-topic-bar__meta">
        Автор:{" "}
        <Nick name={topic.author as string} gender={topic.authorGender as string} onOpen={props.onOpenProfile} />{" "}
        • Создана: <time dateTime={(topic.createdAt as string) || ""}>{fmtDateTime(topic.createdAt as string)}</time>{" "}
        • Просмотров: {fmtNum(topic.views as number)}
        • Ответов: {fmtNum(answers)}
        • Обновлено: <time dateTime={(topic.lastActivityAt as string) || ""}>{fmtRecent(topic.lastActivityAt as string)}</time>
      </div>

      {/* БЛОК 4 — Кнопки. */}
      <div className="sk-topic-bar__actions">
        {/* «Ответить» — синяя большая, главная. */}
        <button
          type="button"
          className="sk-btn-answer"
          onClick={props.onReply}
          disabled={isArchived || isClosed}
          title={isArchived ? "Тема в архиве" : isClosed ? "Тема закрыта" : "Ответить в теме"}
        >
          Ответить
        </button>

        {/* «★» — звёздочка (В избранное), без текста. */}
        <button
          type="button"
          className={`sk-topic-bar__icon${isFav ? " is-active" : ""}`}
          onClick={() => {
            props.favorites.toggle(topicId);
            props.notify(props.favorites.has(topicId) ? "Удалено из избранного" : "Добавлено в избранное");
          }}
          title={isFav ? "Убрать из избранного" : "Добавить в избранное"}
          aria-label={isFav ? "Убрать из избранного" : "Добавить в избранное"}
        >
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path
              d="M12 2l2.9 6.3 6.8.7-5.1 4.6 1.5 6.7L12 17.3 5.9 20.3l1.5-6.7-5.1-4.6 6.8-.7L12 2z"
              fill={isFav ? "currentColor" : "none"}
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinejoin="round"
            />
          </svg>
        </button>

        {/* «Поиск по теме» — серая ссылка с иконкой лупы. */}
        <button
          type="button"
          className="sk-topic-bar__search"
          onClick={() => props.setInTopicSearch(!props.inTopicSearch)}
          title="Поиск по теме"
        >
          <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
            <circle cx="11" cy="11" r="6.5" fill="none" stroke="currentColor" strokeWidth="1.8" />
            <path d="M16 16l4.5 4.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
          Поиск по теме
        </button>

        {/* «Новые (N)» — компактная, появляется при newCount > 0. */}
        {newCount > 0 && (
          <button
            type="button"
            className="sk-topic-bar__new"
            onClick={props.onJumpToNew}
            title={`К первому непрочитанному — сообщение №${answers - newCount + 1}`}
          >
            → Новые ({newCount})
          </button>
        )}

        {/* «⋮ Действия» — выпадающее меню для админов/владельца.
            Обычные пользователи не видят. */}
        {props.isAdmin && !isArchived && (
          <details className="sk-topic-bar__menu">
            <summary className="sk-topic-bar__menu-trigger" title="Действия с темой" aria-label="Действия с темой">
              <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
                <circle cx="5"  cy="12" r="1.8" fill="currentColor" />
                <circle cx="12" cy="12" r="1.8" fill="currentColor" />
                <circle cx="19" cy="12" r="1.8" fill="currentColor" />
              </svg>
            </summary>
            <div className="sk-topic-bar__menu-dropdown">
              {isClosed ? (
                <button
                  type="button"
                  className="sk-topic-bar__menu-item"
                  onClick={() => {
                    if (window.confirm("Открыть тему снова? Пользователи смогут писать новые сообщения.")) {
                      props.topicAction("open", "Тема снова открыта — можно писать сообщения");
                    }
                  }}
                >
                  Открыть тему
                </button>
              ) : (
                <button
                  type="button"
                  className="sk-topic-bar__menu-item"
                  onClick={() => {
                    if (window.confirm("Закрыть тему? Читать её сможет каждый, но новые сообщения будут запрещены.")) {
                      props.topicAction("close", "Тема закрыта — новые сообщения запрещены");
                    }
                  }}
                >
                  Закрыть тему
                </button>
              )}
              {(props.isAdmin || props.isOwner) && (
                <button
                  type="button"
                  className="sk-topic-bar__menu-item sk-topic-bar__menu-item--danger"
                  onClick={() => {
                    if (window.confirm("Удалить тему? Она исчезнет из списков и поиска.")) {
                      props.topicAction("delete", "Тема удалена");
                    }
                  }}
                >
                  Удалить тему
                </button>
              )}
            </div>
          </details>
        )}
      </div>

      {/* Инпут поиска по теме (показывается при клике на «Поиск по теме»). */}
      {props.inTopicSearch && (
        <div className="sk-topic-bar__search-input">
          <input
            type="text"
            value={props.topicQ}
            onChange={(e) => props.setTopicQ(e.target.value)}
            placeholder="Введите текст для поиска в теме…"
            autoFocus
          />
          <button
            type="button"
            onClick={() => {
              props.setInTopicSearch(false);
              props.setTopicQ("");
            }}
            title="Закрыть поиск"
          >
            ✕
          </button>
        </div>
      )}
    </header>
  );
}
