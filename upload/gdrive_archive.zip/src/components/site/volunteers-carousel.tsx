import React, { useEffect, useRef, useState } from 'react';

/**
 * ТЗ 2026-09-25 «Карусель баннеров внизу — увеличить пропорционально +
 * симметричные отступы + адаптив».
 *
 * Что изменилось:
 *   • Баннеры увеличены ПРОПОРЦИОНАЛЬНО: 240×150 → 320×200 (пропорция
 *     1.6:1 сохранена, +33% по обоим измерениям — крупнее в целом, не
 *     просто растянуты по вертикали).
 *   • Симметричные отступы: было marginTop:20 / marginBottom:10 (сверху
 *     больше, чем снизу) → стало marginTop:15 / marginBottom:15 (строго
 *     одинаково).
 *   • Шрифт увеличен: название 16→17px, подзаголовок 11→12px.
 *   • Padding карточки: 12px 14px → 14px 16px (больше воздуха).
 *   • Тень усилена: 0 2px 5px → 0 3px 8px (заметнее на крупных карточках).
 *   • На мобильных (≤640px): баннеры уменьшаются до 260×165, шрифт
 *     15/11px, padding 10px 12px — остаются читаемыми.
 *   • Step прокрутки вычисляется динамически из ширины карточки через
 *     ResizeObserver — на любом экране шаг = ширина_карточки + 4px зазор.
 *
 * Стили вынесены из inline-style в CSS-классы (.volunteers-carousel,
 * .volunteers-carousel-track, .volunteers-card, .volunteers-card-name,
 * .volunteers-card-sub) — см. src/app/globals.css.
 */
export default function VolunteersCarousel() {
  const carouselRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);
  const stepRef = useRef<number>(324); // default: 320px + 4px gap (десктоп)

  // Динамически вычисляем step из ширины первой карточки — на любом
  // экране (десктоп/планшет/мобильный) шаг будет точным.
  useEffect(() => {
    const container = carouselRef.current;
    if (!container) return;
    const updateStep = () => {
      const card = container.querySelector<HTMLElement>('.volunteers-card');
      if (card) {
        const w = card.offsetWidth;
        // +4px — это gap между карточками (см. .volunteers-carousel-track).
        stepRef.current = w + 4;
      }
    };
    updateStep();
    const ro = new ResizeObserver(updateStep);
    ro.observe(container);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const container = carouselRef.current;
    if (!container) return;

    // Дублируем элементы в DOM для бесшовного бесконечного круга
    const originalChildren = Array.from(container.children);
    originalChildren.forEach((child) => {
      const clone = child.cloneNode(true);
      container.appendChild(clone);
    });

    const scrollInterval = setInterval(() => {
      if (isPaused) return;

      // Если доехали до середины (конца оригинальных элементов) — незаметно прыгаем в начало
      if (container.scrollLeft >= container.scrollWidth / 2) {
        container.scrollLeft = 0;
      }

      container.scrollBy({ left: stepRef.current, behavior: 'smooth' });
    }, 2500);

    return () => clearInterval(scrollInterval);
  }, [isPaused]);

  // Данные наших сочных сахалинских карточек
  const partners = [
    { name: "ПСО СОВА", sub: "Поисково-спасательный отряд", bg: "#1A1A1A", text: "#FFFFFF", subColor: "#FFD600", url: "https://pso-sova.ru" },
    { name: "ЛизаAlert", sub: "Поиск пропавших людей", bg: "#FF6D00", text: "#FFFFFF", subColor: "#FFFFFF", url: "https://lizaalert.org" },
    { name: "Помощь животным", sub: "Добрые сердца Сахалина", bg: "#00796B", text: "#FFFFFF", subColor: "#B2DFDB", url: "#" },
    { name: "ЭкоСахалин", sub: "Защита природы острова", bg: "#4CAF50", text: "#FFFFFF", subColor: "#E8F5E9", url: "#" },
    { name: "Я Донор Сахалин", sub: "Служба сдачи крови", bg: "#C62828", text: "#FFFFFF", subColor: "#FFCDD2", url: "#" },
    { name: "Красный Крест", sub: "Сахалинское отделение", bg: "#D32F2F", text: "#FFFFFF", subColor: "#FFFFFF", url: "#" }
  ];

  return (
    // Внешний контейнер: симметричные отступы marginTop:15 / marginBottom:15
    // (раньше было 20/10 — сверху больше, чем снизу).
    <div className="volunteers-carousel">
      <div
        ref={carouselRef}
        className="volunteers-carousel-track"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        onTouchStart={() => setIsPaused(true)}
        onTouchEnd={() => setTimeout(() => setIsPaused(false), 4000)}
      >
        {partners.map((p, idx) => (
          <a
            key={idx}
            href={p.url}
            target="_blank"
            rel="noopener noreferrer"
            className="volunteers-card"
            style={{ backgroundColor: p.bg }}
          >
            <span
              className="volunteers-card-name"
              style={{ color: p.text }}
            >
              {p.name}
            </span>
            <span
              className="volunteers-card-sub"
              style={{ color: p.subColor }}
            >
              {p.sub}
            </span>
          </a>
        ))}
      </div>
    </div>
  );
}
