/**
 * ТЗ 2026-09-25 «Тестовые объявления» — скрипт создания 9 реальных
 * объявлений в БД через prisma (напрямую, без API — не нужна авторизация).
 *
 * Запуск: cd /home/z/my-project && bun scripts/seed-ads-posts.ts
 *
 * Создаёт 9 записей в таблице AdListing (по 3 на каждую из 3 вкладок
 * FlatBoard на странице /obyavleniya):
 *   give      — Отдам даром / Поделюсь (детские книги, диван, игрушки)
 *   need      — Приму в дар / Нужна помощь (коляска, куртка, учебники)
 *   lostfound — Бюро находок (ключи, телефон, серёжка)
 *
 * Автор — первый найденный в БД пользователь (role=admin/moderator/user).
 */

import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  // Найти первого пользователя в БД (любого)
  const author = await prisma.user.findFirst({
    orderBy: { createdAt: "asc" },
  });

  if (!author) {
    console.error("❌ В БД нет ни одного пользователя. Запустите seed.js сначала.");
    process.exit(1);
  }

  console.log(`✅ Автор объявлений: ${author.nickname} (${author.email}, role=${author.role})`);

  const posts = [
    // Вкладка «Отдам даром / Поделюсь» (rubric: "give")
    {
      rubric: "give",
      title: "Детские книги",
      text: "Отдам детские книги. Хорошее состояние, от 3 до 7 лет. Забрать можно в Южно-Сахалинске, район Луговое.",
      place: "Южно-Сахалинск",
      authorId: author.id,
      authorName: author.nickname,
    },
    {
      rubric: "give",
      title: "Диван",
      text: "Отдам диван. Не новый, но крепкий. Самовывоз с ул. Ленина.",
      place: "Южно-Сахалинск",
      authorId: author.id,
      authorName: author.nickname,
    },
    {
      rubric: "give",
      title: "Игрушки",
      text: "Отдам пакет с игрушками. Ребёнок вырос, всё чистое. Пишите в личку.",
      place: "Корсаков",
      authorId: author.id,
      authorName: author.nickname,
    },
    // Вкладка «Приму в дар / Нужна помощь» (rubric: "need")
    {
      rubric: "need",
      title: "Детская коляска",
      text: "Ищу детскую коляску. Можно б/у, главное чтобы колёса рабочие.",
      place: "Южно-Сахалинск",
      authorId: author.id,
      authorName: author.nickname,
    },
    {
      rubric: "need",
      title: "Зимняя куртка 52 размера",
      text: "Нужна зимняя куртка 52 размера. Буду очень благодарен.",
      place: "Холмск",
      authorId: author.id,
      authorName: author.nickname,
    },
    {
      rubric: "need",
      title: "Учебники за 8 класс",
      text: "Ищу учебники за 8 класс. Можно старые, главное чтобы страницы были целые.",
      place: "Долинск",
      authorId: author.id,
      authorName: author.nickname,
    },
    // Вкладка «Бюро находок (Потерял / Нашёл)» (rubric: "lostfound")
    {
      rubric: "lostfound",
      title: "Потерял ключи",
      text: "Потерял ключи с брелком в районе парка. Если нашли — напишите.",
      place: "Южно-Сахалинск",
      authorId: author.id,
      authorName: author.nickname,
    },
    {
      rubric: "lostfound",
      title: "Нашёл телефон",
      text: "Нашёл телефон на остановке. Экран целый, блокировка стоит. Пишите, опишите модель.",
      place: "Южно-Сахалинск",
      authorId: author.id,
      authorName: author.nickname,
    },
    {
      rubric: "lostfound",
      title: "Потеряла серёжку",
      text: "Потеряла серёжку в автобусе №18. Золотая, с камушком. Очень дорога как память.",
      place: "Южно-Сахалинск",
      authorId: author.id,
      authorName: author.nickname,
    },
  ];

  let created = 0;
  for (const p of posts) {
    const post = await prisma.adListing.create({ data: p });
    console.log(`  ✓ ${post.rubric}: ${post.title} (id=${post.id})`);
    created++;
  }

  console.log(`\n✅ Создано ${created} объявлений в таблице AdListing.`);
  console.log("   Теперь на странице /obyavleniya каждая вкладка имеет реальные объявления.");
}

main()
  .catch((e) => {
    console.error("❌ Ошибка:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
